<? php

	include("dbconn.php");
	
	
	$name ="Vijay";
	$age ="23";
	$adress = "Kanminike";
	
	echo $name;
	
	$sql = "INSERT INTO user (name,Age,Address) values ('$name','$age','$address');";
	echo $sql;
	if(mysqli_query($conn,$sql)) {
		echo "Success";
	} else {
		echo "Not Success!";
	}

?>